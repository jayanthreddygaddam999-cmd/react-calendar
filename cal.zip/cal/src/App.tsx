import React from 'react';
import Calendar from './components/Calendar';
import './App.css';

function App() {
  const today = new Date(); // Today's date

  return (
    <div className="App">
      <header className="App-header">
        <h1>React Calendar Component</h1>
        <p className="subtitle">Select month and year to view the calendar</p>
        
        <div className="calendar-container">
          <Calendar date={today} />
        </div>
      </header>
    </div>
  );
}

export default App;
