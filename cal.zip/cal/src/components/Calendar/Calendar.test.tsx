import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import Calendar from './Calendar';

describe('Calendar Component', () => {
  describe('Rendering', () => {
    it('renders the calendar component', () => {
      const testDate = new Date(2022, 9, 3); // October 3, 2022
      render(<Calendar date={testDate} />);
      
      const calendar = screen.getByTestId('calendar');
      expect(calendar).toBeInTheDocument();
    });

    it('displays the correct month and year', () => {
      const testDate = new Date(2022, 9, 3); // October 3, 2022
      render(<Calendar date={testDate} />);
      
      expect(screen.getByText('October 2022')).toBeInTheDocument();
    });

    it('displays all days of the week', () => {
      const testDate = new Date(2022, 9, 3);
      render(<Calendar date={testDate} />);
      
      const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      daysOfWeek.forEach(day => {
        expect(screen.getByText(day)).toBeInTheDocument();
      });
    });

    it('displays the correct month and year for different dates', () => {
      const testDate = new Date(2020, 2, 23); // March 23, 2020
      render(<Calendar date={testDate} />);
      
      expect(screen.getByText('March 2020')).toBeInTheDocument();
    });
  });

  describe('Date Highlighting', () => {
    it('highlights the correct date from the prop', () => {
      const testDate = new Date(2022, 9, 3); // October 3, 2022
      render(<Calendar date={testDate} />);
      
      const highlightedDate = screen.getByTestId('highlighted-date');
      expect(highlightedDate).toBeInTheDocument();
      expect(highlightedDate).toHaveTextContent('3');
    });

    it('highlights the correct date for different dates', () => {
      const testDate = new Date(2020, 2, 23); // March 23, 2020
      render(<Calendar date={testDate} />);
      
      const highlightedDate = screen.getByTestId('highlighted-date');
      expect(highlightedDate).toBeInTheDocument();
      expect(highlightedDate).toHaveTextContent('23');
    });

    it('highlights the first day of the month correctly', () => {
      const testDate = new Date(2022, 0, 1); // January 1, 2022
      render(<Calendar date={testDate} />);
      
      const highlightedDate = screen.getByTestId('highlighted-date');
      expect(highlightedDate).toBeInTheDocument();
      expect(highlightedDate).toHaveTextContent('1');
    });

    it('highlights the last day of the month correctly', () => {
      const testDate = new Date(2022, 0, 31); // January 31, 2022
      render(<Calendar date={testDate} />);
      
      const highlightedDate = screen.getByTestId('highlighted-date');
      expect(highlightedDate).toBeInTheDocument();
      expect(highlightedDate).toHaveTextContent('31');
    });
  });

  describe('Calendar Grid', () => {
    it('displays dates for the correct month', () => {
      const testDate = new Date(2022, 9, 3); // October 2022 has 31 days
      render(<Calendar date={testDate} />);
      
      // Check that dates 1-31 are present
      expect(screen.getByText('1')).toBeInTheDocument();
      expect(screen.getByText('31')).toBeInTheDocument();
    });

    it('aligns dates correctly with day headers', () => {
      const testDate = new Date(2022, 9, 3); // October 1, 2022 is a Saturday (day 6)
      render(<Calendar date={testDate} />);
      
      // October 1, 2022 falls on a Saturday, so it should be in the 7th column
      // We can verify by checking that the first day appears after empty cells
      const calendar = screen.getByTestId('calendar');
      expect(calendar).toBeInTheDocument();
    });

    it('handles months that start on different days of the week', () => {
      // Test a month that starts on Sunday (day 0)
      const sundayStart = new Date(2022, 8, 1); // September 1, 2022 is a Thursday
      const { rerender } = render(<Calendar date={sundayStart} />);
      expect(screen.getByText('September 2022')).toBeInTheDocument();
      
      // Test a month that starts on Monday (day 1)
      const mondayStart = new Date(2022, 5, 1); // June 1, 2022 is a Wednesday
      rerender(<Calendar date={mondayStart} />);
      expect(screen.getByText('June 2022')).toBeInTheDocument();
    });
  });

  describe('Edge Cases', () => {
    it('handles leap year February correctly', () => {
      const testDate = new Date(2020, 1, 29); // February 29, 2020 (leap year)
      render(<Calendar date={testDate} />);
      
      expect(screen.getByText('February 2020')).toBeInTheDocument();
      const highlightedDate = screen.getByTestId('highlighted-date');
      expect(highlightedDate).toHaveTextContent('29');
    });

    it('handles non-leap year February correctly', () => {
      const testDate = new Date(2022, 1, 28); // February 28, 2022 (non-leap year)
      render(<Calendar date={testDate} />);
      
      expect(screen.getByText('February 2022')).toBeInTheDocument();
      const highlightedDate = screen.getByTestId('highlighted-date');
      expect(highlightedDate).toHaveTextContent('28');
    });

    it('handles year boundary correctly', () => {
      const testDate = new Date(2022, 11, 31); // December 31, 2022
      render(<Calendar date={testDate} />);
      
      expect(screen.getByText('December 2022')).toBeInTheDocument();
      const highlightedDate = screen.getByTestId('highlighted-date');
      expect(highlightedDate).toHaveTextContent('31');
    });
  });
});

