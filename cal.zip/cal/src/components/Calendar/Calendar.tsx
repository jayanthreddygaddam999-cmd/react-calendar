import React, { useState, useEffect } from 'react';
import styles from './Calendar.module.css';

export interface CalendarProps {
  date?: Date;
}

const DAYS_OF_WEEK = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

/**
 * Calendar component that displays a calendar for a given date's month and year,
 * with the specified date highlighted. Includes month and year selection.
 */
const Calendar: React.FC<CalendarProps> = ({ date }) => {
  const initialDate = date || new Date();
  const [selectedYear, setSelectedYear] = useState(initialDate.getFullYear());
  const [selectedMonth, setSelectedMonth] = useState(initialDate.getMonth());
  const [selectedDay, setSelectedDay] = useState(initialDate.getDate());

  // Update when date prop changes
  useEffect(() => {
    if (date) {
      setSelectedYear(date.getFullYear());
      setSelectedMonth(date.getMonth());
      setSelectedDay(date.getDate());
    }
  }, [date]);

  const year = selectedYear;
  const month = selectedMonth;
  const day = selectedDay;

  // Get the first day of the month and the number of days in the month
  const firstDayOfMonth = new Date(year, month, 1);
  const lastDayOfMonth = new Date(year, month + 1, 0);
  const daysInMonth = lastDayOfMonth.getDate();
  const startingDayOfWeek = firstDayOfMonth.getDay();

  // Generate array of dates for the calendar grid
  const calendarDays: (number | null)[] = [];

  // Add empty cells for days before the first day of the month
  for (let i = 0; i < startingDayOfWeek; i++) {
    calendarDays.push(null);
  }

  // Add all days of the month
  for (let i = 1; i <= daysInMonth; i++) {
    calendarDays.push(i);
  }

  // Generate year options (current year ± 50 years)
  const currentYear = new Date().getFullYear();
  const years = [];
  for (let i = currentYear - 50; i <= currentYear + 50; i++) {
    years.push(i);
  }

  // Handle month change
  const handleMonthChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newMonth = parseInt(e.target.value);
    setSelectedMonth(newMonth);
    // Adjust day if it's invalid for the new month (e.g., Feb 31 -> Feb 28/29)
    const daysInNewMonth = new Date(year, newMonth + 1, 0).getDate();
    if (day > daysInNewMonth) {
      setSelectedDay(daysInNewMonth);
    }
  };

  // Handle year change
  const handleYearChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newYear = parseInt(e.target.value);
    setSelectedYear(newYear);
    // Adjust day for leap year February
    const daysInMonth = new Date(newYear, month + 1, 0).getDate();
    if (day > daysInMonth) {
      setSelectedDay(daysInMonth);
    }
  };

  // Format month and year for display
  const monthYear = `${MONTHS[month]} ${year}`;

  return (
    <div className={styles.calendar} data-testid="calendar">
      {/* Month and Year Header with Selectors */}
      <div className={styles.header}>
        <div className={styles.monthYearSelector}>
          <select
            className={styles.monthSelect}
            value={month}
            onChange={handleMonthChange}
            aria-label="Select month"
          >
            {MONTHS.map((monthName, index) => (
              <option key={index} value={index}>
                {monthName}
              </option>
            ))}
          </select>
          <select
            className={styles.yearSelect}
            value={year}
            onChange={handleYearChange}
            aria-label="Select year"
          >
            {years.map((y) => (
              <option key={y} value={y}>
                {y}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Days of Week Header */}
      <div className={styles.daysOfWeek}>
        {DAYS_OF_WEEK.map((dayName) => (
          <div key={dayName} className={styles.dayName}>
            {dayName}
          </div>
        ))}
      </div>

      {/* Calendar Grid */}
      <div className={styles.calendarGrid}>
        {calendarDays.map((dateNum, index) => {
          const isHighlighted = dateNum === day;
          const cellKey = `day-${index}-${dateNum}`;

          return (
            <div
              key={cellKey}
              className={`${styles.calendarDay} ${dateNum === null ? styles.empty : ''} ${isHighlighted ? styles.highlighted : ''}`}
              data-testid={isHighlighted ? 'highlighted-date' : undefined}
              onClick={() => dateNum !== null && setSelectedDay(dateNum)}
            >
              {dateNum !== null ? dateNum : ''}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Calendar;

